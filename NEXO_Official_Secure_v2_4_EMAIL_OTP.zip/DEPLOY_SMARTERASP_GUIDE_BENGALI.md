# SmarterASP Deploy Guide — NEXO v2.3

1. SmarterASP Control Panel → Github Deploy / Auto Build and Deploy.
2. Deployment Method: Upload A Zip File.
3. Upload: `NEXO_Official_Secure_v2_3_HARDENED.zip`.
4. Deploy Now চাপুন।
5. Deploy success হলে Application Pool → Recycle / Restart করুন।
6. Open: `https://YOUR_DOMAIN/api/health`.
7. First admin setup-এর আগে File Manager → site root → data → `setup-token.txt` খুলে token copy করুন।
8. `/mobile/` খুলে First Admin form পূরণ করুন এবং Setup Token paste করুন।

## Security Reminder

- `data/.secret` কখনো ZIP-এর ভিতরে distribute করবেন না।
- `setup-token.txt` publicly share করবেন না।
- Production-এ `NEXO_ALLOW_DEV_OTP=true` করবেন না।

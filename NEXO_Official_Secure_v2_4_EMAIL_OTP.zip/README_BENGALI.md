# NEXO Official Secure v2.4 — Email OTP Build

এই build-এ v2.3 Hardened security fixes-এর উপর real Email OTP via SMTP যোগ করা হয়েছে।

## নতুন কী আছে

- Email OTP sending via SMTP/Nodemailer
- Login OTP password verify করার পরে যাবে
- Forgot Password OTP email-এ যাবে
- OTP setup status admin security route-এ দেখা যাবে
- v2.3 security fixes retained: file ACL, redacted audit, setup token, strong password, token revoke, CSP/HSTS, magic-byte upload validation

## Default behavior

`NEXO_REQUIRE_OTP=false` রাখা হয়েছে যাতে SMTP configure করার আগে system lock না হয়।
SMTP setup করার পরে `NEXO_REQUIRE_OTP=true` এবং `OTP_EMAIL_ENABLED=true` করো।

## Required user field

Email OTP চালাতে প্রত্যেক active user-এর valid email থাকা দরকার। শুধু mobile থাকলে Email OTP যাবে না।

## Test links

- `/api/health`
- `/mobile/`
- `/admin/`


# NEXO Email OTP Setup Guide — SmarterASP

## 1. Deploy

SmarterASP → Github Deploy / Auto Build and Deploy → Upload ZIP → `NEXO_Official_Secure_v2_4_EMAIL_OTP.zip` → Deploy Now.

Deploy success হলে Application Pool Recycle / Restart করো।

## 2. SMTP credentials প্রস্তুত করো

Gmail ব্যবহার করলে Google Account-এ 2-Step Verification ON করে App Password তৈরি করতে হবে।

Example Gmail SMTP:

```text
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=yourgmail@gmail.com
SMTP_PASS=16 character app password
SMTP_FROM=NEXO <yourgmail@gmail.com>
NEXO_PUBLIC_URL=https://nexoofficial.in
OTP_EMAIL_ENABLED=true
NEXO_REQUIRE_OTP=true
```

Port 465 ব্যবহার করলে:

```text
SMTP_PORT=465
SMTP_SECURE=true
```

## 3. SmarterASP-এ কোথায় বসাবে

File Manager → site root → `web.config` edit করো।

এই জায়গাগুলো পূরণ করো:

```xml
<environmentVariable name="OTP_EMAIL_ENABLED" value="true" />
<environmentVariable name="NEXO_REQUIRE_OTP" value="true" />
<environmentVariable name="NEXO_PUBLIC_URL" value="https://nexoofficial.in" />
<environmentVariable name="SMTP_HOST" value="smtp.gmail.com" />
<environmentVariable name="SMTP_PORT" value="587" />
<environmentVariable name="SMTP_SECURE" value="false" />
<environmentVariable name="SMTP_USER" value="yourgmail@gmail.com" />
<environmentVariable name="SMTP_PASS" value="your_app_password" />
<environmentVariable name="SMTP_FROM" value="NEXO <yourgmail@gmail.com>" />
```

Save করার পর Application Pool → Recycle / Restart.

## 4. Test

1. কোনো user-এর profile-এ email আছে কিনা check করো।
2. Login page → Login ID + Password → Enter NEXO.
3. OTP email-এ আসবে।
4. OTP দিলে login হবে।
5. Forgot Password-ও email OTP দিয়ে কাজ করবে।

## 5. Safety

- SMTP password কখনও public chat/repo-তে দেবে না।
- Gmail normal password নয়; App Password ব্যবহার করো।
- Production-এ `NEXO_ALLOW_DEV_OTP=false` এবং `NEXO_HIDE_DEV_OTP=true` রাখো।

## 6. Lockout safety

SMTP ঠিকভাবে কাজ করছে কিনা নিশ্চিত না হওয়া পর্যন্ত `NEXO_REQUIRE_OTP=false` রাখো।
প্রথমে email test করে তারপর `true` করো।

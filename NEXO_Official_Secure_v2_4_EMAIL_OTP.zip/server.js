'use strict';

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const APP_NAME = 'NEXO Node Running App';
const VERSION = '2.4.0';
const BASE_DIR = __dirname;
const DATA_DIR = path.join(BASE_DIR, 'data');
const UPLOAD_DIR = path.join(BASE_DIR, 'uploads');
const WEB_DIR = path.join(BASE_DIR, 'web');
const DB_PATH = path.join(DATA_DIR, 'db.json');
const ANCHOR_PATH = path.join(DATA_DIR, 'audit_anchors.ndjson');
const SECRET_PATH = path.join(DATA_DIR, '.secret');
const SETUP_TOKEN_PATH = path.join(DATA_DIR, 'setup-token.txt');
const PBKDF2_ITERATIONS = parseInt(process.env.NEXO_PBKDF2_ITERATIONS || '310000', 10);
const LEGACY_PBKDF2_ITERATIONS = 120000;
const MIN_PASSWORD_LENGTH = 10;
const TOKEN_TTL_SECONDS = parseInt(process.env.NEXO_TOKEN_TTL_SECONDS || String(8 * 60 * 60), 10);

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

function now() { return new Date().toISOString(); }
function newId() { return crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : crypto.randomBytes(16).toString('hex'); }
function stableStringify(obj) {
  if (obj === null || typeof obj !== 'object') return JSON.stringify(obj);
  if (Array.isArray(obj)) return '[' + obj.map(stableStringify).join(',') + ']';
  return '{' + Object.keys(obj).sort().map(k => JSON.stringify(k) + ':' + stableStringify(obj[k])).join(',') + '}';
}
function sha256Text(s) { return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex'); }
function sha256Bytes(b) { return crypto.createHash('sha256').update(b).digest('hex'); }
const OTP_TTL_MS = 10 * 60 * 1000;
const SHOW_DEV_OTP = process.env.NEXO_ALLOW_DEV_OTP === 'true' && process.env.NODE_ENV !== 'production';
const ALLOWED_FILE_EXTS = new Set(['.pdf','.png','.jpg','.jpeg','.webp','.gif','.txt','.csv','.json']);
const PREVIEW_EXTS = new Set(['.pdf','.png','.jpg','.jpeg','.webp','.gif','.txt','.csv','.json']);
const BLOCKED_FILE_EXTS = new Set(['.html','.htm','.svg','.js','.mjs','.css','.xml','.xhtml','.exe','.bat','.cmd','.ps1','.sh']);
function extOf(filename){ return path.extname(String(filename || '')).toLowerCase(); }
function safePublicUser(u) { if (!u) return null; const { password_salt, password_hash, password_iterations, ...rest } = u; return rest; }
function redactSensitive(v) {
  if (v === null || v === undefined) return v;
  if (Array.isArray(v)) return v.map(redactSensitive);
  if (typeof v === 'object') {
    const out = {};
    for (const [k, val] of Object.entries(v)) {
      if (/pass(word)?|token|otp|secret|key|auth/i.test(k)) out[k] = '[REDACTED]';
      else out[k] = redactSensitive(val);
    }
    return out;
  }
  return v;
}
function passwordPolicyError(password) {
  const p = String(password || '');
  if (p.length < MIN_PASSWORD_LENGTH) return `Password must be at least ${MIN_PASSWORD_LENGTH} characters`;
  if (!/[A-Z]/.test(p) || !/[a-z]/.test(p) || !/[0-9]/.test(p)) return 'Password must contain uppercase, lowercase and number';
  return null;
}
function readOrCreateSecret(filePath, bytes=32) {
  const envSecret = process.env.NEXO_JWT_SECRET || process.env.JWT_SECRET || '';
  if (envSecret && envSecret.length >= 32) return envSecret;
  if (fs.existsSync(filePath)) {
    const existing = fs.readFileSync(filePath, 'utf8').trim();
    const compromised = new Set(['d1636a9ec36959f794a865ee4d4fe975275e46fe3d9b794310e0ddbab6a7154e']);
    if (existing && !compromised.has(existing)) return existing;
  }
  const generated = crypto.randomBytes(bytes).toString('hex');
  fs.writeFileSync(filePath, generated, { mode: 0o600 });
  return generated;
}
let SECRET_KEY = readOrCreateSecret(SECRET_PATH, 32);
function getSetupToken() {
  const envToken = process.env.NEXO_SETUP_TOKEN || '';
  if (envToken && envToken.length >= 12) return envToken;
  if (fs.existsSync(SETUP_TOKEN_PATH)) return fs.readFileSync(SETUP_TOKEN_PATH, 'utf8').trim();
  const generated = crypto.randomBytes(16).toString('hex');
  fs.writeFileSync(SETUP_TOKEN_PATH, generated, { mode: 0o600 });
  return generated;
}
function requireSetupToken(token) {
  const expected = getSetupToken();
  const got = String(token || '');
  if (!got || got.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected))) {
    throw Object.assign(new Error('Invalid setup token'), { status: 403 });
  }
}


function defaultDb() {
  return { meta: { app: APP_NAME, version: VERSION, created_at: now() }, units: [], users: [], conversations: [], conversation_members: [], messages: [], commands: [], command_recipients: [], clarifications: [], attachments: [], audit_logs: [], audit_anchors: [], otps: [], revoked_tokens: [] };
}
function loadDb() {
  if (!fs.existsSync(DB_PATH)) return defaultDb();
  try {
    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    const def = defaultDb();
    for (const k of Object.keys(def)) if (db[k] === undefined) db[k] = def[k];
    if (!db.otps) db.otps = [];
    if (!db.revoked_tokens) db.revoked_tokens = [];
    if (!db.audit_anchors) db.audit_anchors = [];
    if (!db.meta) db.meta = def.meta;
    db.meta.version = VERSION;
    return db;
  } catch (e) { return defaultDb(); }
}
function saveDb(db) {
  const tmp = DB_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_PATH);
}
function mutate(fn) { const db = loadDb(); const result = fn(db); saveDb(db); return result; }
function read(fn) { return fn(loadDb()); }

function hashPassword(password, salt, iterations) {
  const s = salt || crypto.randomBytes(16).toString('hex');
  const it = iterations || PBKDF2_ITERATIONS;
  const digest = crypto.pbkdf2Sync(String(password), s, it, 32, 'sha256').toString('hex');
  return { salt: s, digest, iterations: it };
}
function verifyPassword(password, salt, digest, iterations) {
  const it = iterations || LEGACY_PBKDF2_ITERATIONS;
  const got = crypto.pbkdf2Sync(String(password), salt, it, 32, 'sha256').toString('hex');
  try { return crypto.timingSafeEqual(Buffer.from(got), Buffer.from(digest)); } catch { return false; }
}
function b64url(obj) { return Buffer.from(JSON.stringify(obj)).toString('base64url'); }
function makeToken(userId) {
  const iat = Math.floor(Date.now()/1000);
  const body = b64url({ uid: userId, jti: newId(), iat, exp: iat + TOKEN_TTL_SECONDS });
  const sig = crypto.createHmac('sha256', SECRET_KEY).update(body).digest('hex');
  return body + '.' + sig;
}

function readToken(token) {
  try {
    const [body, sig] = String(token || '').split('.');
    if (!body || !sig) return null;
    const expected = crypto.createHmac('sha256', SECRET_KEY).update(body).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if ((payload.exp || 0) < Math.floor(Date.now()/1000)) return null;
    return payload;
  } catch { return null; }
}
function createAuditAnchor(db, reason) {
  if (!db.audit_logs.length) return null;
  const last = db.audit_logs[db.audit_logs.length - 1];
  const previousAnchor = db.audit_anchors && db.audit_anchors.length ? db.audit_anchors[db.audit_anchors.length - 1].anchor_hash : 'ANCHOR_GENESIS';
  const created_at = now();
  const payload = { index: (db.audit_anchors || []).length + 1, audit_count: db.audit_logs.length, last_event_hash: last.event_hash, previous_anchor_hash: previousAnchor, reason: reason || 'PERIODIC', created_at };
  const anchor_hash = crypto.createHmac('sha256', SECRET_KEY).update(stableStringify(payload)).digest('hex');
  const anchor = { ...payload, anchor_hash };
  db.audit_anchors = db.audit_anchors || [];
  db.audit_anchors.push(anchor);
  try { fs.appendFileSync(ANCHOR_PATH, JSON.stringify(anchor) + '\n'); } catch {}
  return anchor;
}
function audit(db, entity_type, entity_id, action_type, actor_id, old_value, new_value) {
  const last = db.audit_logs[db.audit_logs.length - 1];
  const prev_hash = last ? last.event_hash : 'GENESIS';
  const created_at = now();
  const payload = stableStringify({ entity_type, entity_id, action_type, actor_id, old_value, new_value, prev_hash, created_at });
  const event_hash = sha256Text(prev_hash + payload);
  const audit_id = db.audit_logs.length ? Math.max(...db.audit_logs.map(a => a.audit_id || 0)) + 1 : 1;
  old_value = redactSensitive(old_value);
  new_value = redactSensitive(new_value);
  db.audit_logs.push({ audit_id, entity_type, entity_id, action_type, actor_id, old_value, new_value, prev_hash, event_hash, created_at });
  const interval = Math.max(parseInt(process.env.NEXO_AUDIT_ANCHOR_INTERVAL || '25', 10) || 25, 1);
  if (audit_id % interval === 0) createAuditAnchor(db, 'PERIODIC_' + interval);
  return event_hash;
}

function authRequired(req, res, next) {
  const h = req.headers.authorization || '';
  if (!h.toLowerCase().startsWith('bearer ')) return res.status(401).json({ detail: 'Authentication required' });
  const payload = readToken(h.slice(7).trim());
  if (!payload) return res.status(401).json({ detail: 'Invalid or expired token' });
  const user = read(db => {
    if ((db.revoked_tokens || []).some(t => t.jti === payload.jti)) return null;
    return db.users.find(u => u.id === payload.uid && u.status === 'ACTIVE');
  });
  if (!user) return res.status(401).json({ detail: 'User inactive or not found' });
  req.user = user;
  next();
}
function requireAdmin(req, res, next) {
  if (!['SUPER_ADMIN', 'ORG_ADMIN'].includes(req.user.role)) return res.status(403).json({ detail: 'Admin permission required' });
  next();
}
function canIssue(u) { return ['SUPER_ADMIN', 'ORG_ADMIN', 'SUPERIOR', 'OFFICER'].includes(u.role); }
function loginMatch(u, login) { return [u.mobile, u.email, u.employee_id].filter(Boolean).some(x => String(x).toLowerCase() === String(login).toLowerCase()); }

function otpCode() { return String(Math.floor(100000 + Math.random() * 900000)); }
function otpDigest(code) { return sha256Text(SECRET_KEY + ':' + String(code)); }
function cleanupOtps(db) { const t = Date.now(); db.otps = (db.otps || []).filter(o => !o.used_at && new Date(o.expires_at).getTime() > t - 3600000); }
function smtpConfigured() {
  return !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.SMTP_FROM);
}
function buildOtpEmail(user, code, purpose) {
  const appUrl = process.env.NEXO_PUBLIC_URL || 'https://nexoofficial.in';
  const displayPurpose = purpose === 'RESET' ? 'Password Reset' : 'Login';
  const subject = `NEXO ${displayPurpose} OTP`;
  const text = `Your NEXO ${displayPurpose} OTP is ${code}. This OTP is valid for 10 minutes. If you did not request this, please ignore this email. ${appUrl}`;
  const html = `<!doctype html><html><body style="font-family:Arial,sans-serif;background:#f6f8fb;margin:0;padding:24px"><div style="max-width:560px;margin:auto;background:#fff;border-radius:18px;padding:24px;border:1px solid #e5e7eb"><h2 style="margin:0 0 10px;color:#0f172a">NEXO ${displayPurpose} OTP</h2><p style="color:#475569">Hello ${String(user.name || 'User').replace(/[&<>"']/g, '')},</p><p style="color:#475569">Use the following OTP to continue:</p><div style="font-size:34px;letter-spacing:8px;font-weight:700;color:#0b4d94;background:#eef6ff;border-radius:14px;text-align:center;padding:18px;margin:22px 0">${code}</div><p style="color:#475569">This OTP is valid for <b>10 minutes</b>.</p><p style="color:#64748b;font-size:13px">If you did not request this OTP, please ignore this email.</p><p style="color:#94a3b8;font-size:12px">NEXO Official Communication Platform • ${appUrl}</p></div></body></html>`;
  return { subject, text, html };
}
async function sendEmailOtp(user, code, purpose) {
  if (!smtpConfigured()) return { sent: false, channel: 'SMTP_NOT_CONFIGURED' };
  if (!user.email) return { sent: false, channel: 'EMAIL_MISSING' };
  const port = parseInt(process.env.SMTP_PORT || '587', 10);
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || port === 465;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    tls: { rejectUnauthorized: process.env.SMTP_REJECT_UNAUTHORIZED === 'false' ? false : true }
  });
  const mail = buildOtpEmail(user, code, purpose);
  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to: user.email,
    subject: mail.subject,
    text: mail.text,
    html: mail.html
  });
  return { sent: true, channel: 'EMAIL_SMTP', messageId: info.messageId || null, to: user.email };
}
async function sendOtpToUser(user, code, purpose) {
  const msg = `NEXO ${purpose} OTP is ${code}. Valid for 10 minutes.`;
  if (process.env.OTP_EMAIL_ENABLED === 'true' || smtpConfigured()) {
    try { return await sendEmailOtp(user, code, purpose); }
    catch (e) { return { sent: false, channel: 'EMAIL_SMTP_ERROR', error: e.message }; }
  }
  // Optional SMS/HTTP gateway hook. Example: OTP_PROVIDER_URL="https://sms-provider.example/send?to={to}&msg={msg}"
  const to = user.mobile || user.email || user.employee_id || '';
  const tpl = process.env.OTP_PROVIDER_URL || '';
  if (!tpl) return { sent: false, channel: 'PROVIDER_NOT_CONFIGURED' };
  try {
    const url = tpl.replace('{to}', encodeURIComponent(to)).replace('{msg}', encodeURIComponent(msg)).replace('{otp}', encodeURIComponent(code));
    const r = await fetch(url, { method: process.env.OTP_PROVIDER_METHOD || 'GET' });
    return { sent: r.ok, channel: 'HTTP_GATEWAY', status: r.status };
  } catch (e) { return { sent: false, channel: 'HTTP_GATEWAY_ERROR', error: e.message }; }
}
function verifyOtp(db, userId, purpose, code) {
  cleanupOtps(db);
  const rec = (db.otps || []).slice().reverse().find(o => o.user_id === userId && o.purpose === purpose && !o.used_at);
  if (!rec) throw Object.assign(new Error('OTP not found or expired'), { status: 400 });
  if (new Date(rec.expires_at).getTime() < Date.now()) throw Object.assign(new Error('OTP expired'), { status: 400 });
  rec.attempts = (rec.attempts || 0) + 1;
  if (rec.attempts > 5) throw Object.assign(new Error('OTP locked after too many attempts'), { status: 429 });
  const expected = Buffer.from(rec.otp_hash);
  const actual = Buffer.from(otpDigest(code || ''));
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) throw Object.assign(new Error('Invalid OTP'), { status: 400 });
  rec.used_at = now();
  return rec;
}
function uniqueUserOk(db, incoming, skipId) {
  const fields = ['mobile','email','employee_id'];
  for (const f of fields) {
    if (incoming[f] && db.users.some(u => u.id !== skipId && u[f] && String(u[f]).toLowerCase() === String(incoming[f]).toLowerCase())) return { ok: false, field: f };
  }
  return { ok: true };
}
function reportingChain(db, userId) {
  const chain = []; const seen = new Set(); let cur = userId;
  while (cur && !seen.has(cur)) {
    seen.add(cur);
    const u = db.users.find(x => x.id === cur); if (!u) break;
    chain.push({ id: u.id, name: u.name, designation: u.designation });
    cur = u.reports_to_user_id;
  }
  return chain;
}
function isAdminRole(u) { return !!u && ['SUPER_ADMIN','ORG_ADMIN'].includes(u.role); }
function isDirectOrIndirectReport(db, managerId, userId) {
  if (!managerId || !userId || managerId === userId) return false;
  const seen = new Set();
  let cur = userId;
  while (cur && !seen.has(cur)) {
    seen.add(cur);
    const u = db.users.find(x => x.id === cur);
    if (!u) return false;
    if (u.reports_to_user_id === managerId) return true;
    cur = u.reports_to_user_id;
  }
  return false;
}
function visibleUserIdsFor(db, actor) {
  if (isAdminRole(actor)) return new Set(db.users.map(u => u.id));
  const ids = new Set([actor.id]);
  db.users.forEach(u => { if (isDirectOrIndirectReport(db, actor.id, u.id)) ids.add(u.id); });
  if (actor.reports_to_user_id) ids.add(actor.reports_to_user_id);
  return ids;
}
function resolveRecipients(db, body, actor) {
  const ids = new Set(body.assigned_user_ids || []);
  for (const role of (body.assigned_roles || [])) db.users.filter(u => u.role === role && u.status === 'ACTIVE').forEach(u => ids.add(u.id));
  for (const unitId of (body.assigned_unit_ids || [])) db.users.filter(u => u.unit_id === unitId && u.status === 'ACTIVE').forEach(u => ids.add(u.id));
  ids.delete(actor.id);
  if (!isAdminRole(actor)) {
    for (const id of Array.from(ids)) {
      if (!isDirectOrIndirectReport(db, actor.id, id)) ids.delete(id);
    }
  }
  return Array.from(ids).sort();
}

function canReadCommand(db, user, commandId) {
  const c = db.commands.find(x => x.id === commandId);
  if (!c) return false;
  return isAdminRole(user) || c.issuer_user_id === user.id || db.command_recipients.some(cr => cr.command_id === commandId && cr.user_id === user.id);
}
function canAccessFile(db, user, fileId) {
  if (!user) return false;
  if (isAdminRole(user)) return true;
  const f = db.attachments.find(x => x.id === fileId);
  if (!f) return false;
  if (f.uploaded_by === user.id) return true;
  // Message attachment: only conversation members.
  for (const m of db.messages.filter(m => m.attachment_id === fileId)) {
    if (db.conversation_members.some(cm => cm.conversation_id === m.conversation_id && cm.user_id === user.id)) return true;
  }
  // Official command attachment: issuer and assigned recipients.
  for (const c of db.commands.filter(c => Array.isArray(c.attachment_ids) && c.attachment_ids.includes(fileId))) {
    if (canReadCommand(db, user, c.id)) return true;
  }
  // Proof attachment: only submitting user, issuer, admin.
  for (const cr of db.command_recipients.filter(cr => cr.proof_file_id === fileId)) {
    const c = db.commands.find(x => x.id === cr.command_id);
    if (cr.user_id === user.id || (c && c.issuer_user_id === user.id)) return true;
  }
  return false;
}
function allowedTransition(oldStatus, nextStatus) {
  const old = String(oldStatus || 'DELIVERED').toUpperCase();
  const next = String(nextStatus || '').toUpperCase();
  if (next === 'CLARIFICATION') return ['DELIVERED','SEEN','ACKNOWLEDGED','IN_PROGRESS'].includes(old);
  const allowed = {
    DELIVERED: ['SEEN'],
    SEEN: ['ACKNOWLEDGED'],
    ACKNOWLEDGED: ['IN_PROGRESS'],
    IN_PROGRESS: ['COMPLETED','PROOF_SUBMITTED'],
    COMPLETED: ['PROOF_SUBMITTED'],
    PROOF_SUBMITTED: [],
    VERIFIED: [],
    CLOSED: []
  };
  return (allowed[old] || []).includes(next);
}
function looksUtf8Text(buf) {
  if (!buf || !buf.length) return true;
  if (buf.includes(0)) return false;
  const s = buf.toString('utf8');
  return !s.includes('\uFFFD');
}
function validateMagicBytes(file, ext) {
  const b = file.buffer || Buffer.alloc(0);
  if (ext === '.pdf' && b.slice(0,5).toString() !== '%PDF-') throw Object.assign(new Error('Invalid PDF content'), { status: 400 });
  if (ext === '.png' && !b.slice(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]))) throw Object.assign(new Error('Invalid PNG content'), { status: 400 });
  if ((ext === '.jpg' || ext === '.jpeg') && !(b[0]===0xff && b[1]===0xd8 && b[2]===0xff)) throw Object.assign(new Error('Invalid JPEG content'), { status: 400 });
  if (ext === '.gif' && !['GIF87a','GIF89a'].includes(b.slice(0,6).toString())) throw Object.assign(new Error('Invalid GIF content'), { status: 400 });
  if (ext === '.webp' && !(b.slice(0,4).toString()==='RIFF' && b.slice(8,12).toString()==='WEBP')) throw Object.assign(new Error('Invalid WEBP content'), { status: 400 });
  if (['.txt','.csv'].includes(ext) && !looksUtf8Text(b)) throw Object.assign(new Error('Invalid text content'), { status: 400 });
  if (ext === '.json') {
    if (!looksUtf8Text(b)) throw Object.assign(new Error('Invalid JSON content'), { status: 400 });
    try { JSON.parse(b.toString('utf8')); } catch { throw Object.assign(new Error('Invalid JSON content'), { status: 400 }); }
  }
}
function validateUploadFile(file) {
  const original = file && file.originalname || '';
  const ext = extOf(original);
  if (BLOCKED_FILE_EXTS.has(ext) || !ALLOWED_FILE_EXTS.has(ext)) throw Object.assign(new Error('File type not allowed. Allowed: PDF, image, TXT, CSV, JSON.'), { status: 400 });
  const mime = String(file.mimetype || '').toLowerCase();
  if (mime.includes('html') || mime.includes('javascript') || mime.includes('svg') || mime.includes('xml')) throw Object.assign(new Error('Unsafe file MIME type blocked'), { status: 400 });
  validateMagicBytes(file, ext);
  return ext;
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.NEXO_TRUST_PROXY === 'true' ? 1 : false);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
  res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
});
const allowedOrigins = (process.env.NEXO_ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: (origin, cb) => { if (!origin) return cb(null, true); if (!allowedOrigins.length) return cb(null, false); return cb(null, allowedOrigins.includes(origin)); } }));
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true }));

const authRate = new Map();
function rateLimitAuth(req, res, next) {
  const ip = (process.env.NEXO_TRUST_PROXY === 'true' ? (req.ip || '') : (req.socket && req.socket.remoteAddress || '')) || 'unknown';
  const key = ip + ':' + req.path;
  const t = Date.now();
  const rec = authRate.get(key) || { count: 0, first: t };
  if (t - rec.first > 15 * 60 * 1000) { rec.count = 0; rec.first = t; }
  rec.count += 1; authRate.set(key, rec);
  const limit = req.path.includes('otp') ? 8 : 25;
  if (rec.count > limit) return res.status(429).json({ detail: 'Too many requests. Try later.' });
  next();
}

app.get('/', (req, res) => res.sendFile(path.join(WEB_DIR, 'mobile', 'index.html')));
app.get('/mobile/', (req, res) => res.sendFile(path.join(WEB_DIR, 'mobile', 'index.html')));
app.get('/admin/', (req, res) => res.sendFile(path.join(WEB_DIR, 'admin', 'index.html')));
app.use('/static/mobile', express.static(path.join(WEB_DIR, 'mobile')));
app.use('/static/admin', express.static(path.join(WEB_DIR, 'admin')));

app.get('/api/health', (req, res) => res.json({ ok: true, app: APP_NAME, version: VERSION, time: now() }));
app.get('/api/system/security', authRequired, requireAdmin, (req, res) => res.json({ mode: 'OFFICIAL_SECURE', transport: 'HTTPS required', audit_hash_chain: true, hierarchy_restricted_assignment: true, file_preview_inline: true, file_acl: 'context-bound', token_in_url: false, otp_dev_leak: false, otp_required: process.env.NEXO_REQUIRE_OTP === 'true', email_otp_configured: smtpConfigured(), sms_gateway_configured: !!process.env.OTP_PROVIDER_URL, e2e_private_messages: 'foundation-ready; official commands remain auditable' }));
app.get('/api/setup/status', (req, res) => read(db => { if (db.users.length === 0) getSetupToken(); res.json({ ready: db.users.length > 0, setup_token_required: db.users.length === 0, app: APP_NAME }); }));
app.post('/api/setup/first-admin', rateLimitAuth, (req, res) => {
  try {
    const body = req.body || {};
    if (!body.organization_name || !body.unit_name || !body.name || !body.password) return res.status(400).json({ detail: 'Missing required fields' });
    requireSetupToken(body.setup_token);
    const pe = passwordPolicyError(body.password); if (pe) return res.status(400).json({ detail: pe });
    const out = mutate(db => {
      if (db.users.length > 0) throw Object.assign(new Error('First admin already exists'), { status: 400 });
      const unit_id = newId();
      db.units.push({ id: unit_id, name: body.unit_name, parent_unit_id: null, organization_name: body.organization_name, created_at: now() });
      const hp = hashPassword(body.password);
      const user_id = newId();
      const u = { id: user_id, name: body.name, mobile: body.mobile || null, email: body.email || null, employee_id: body.employee_id || null, password_salt: hp.salt, password_hash: hp.digest, password_iterations: hp.iterations, designation: body.designation || 'Founder Admin', rank: body.designation || 'Founder Admin', role: 'SUPER_ADMIN', unit_id, reports_to_user_id: null, status: 'ACTIVE', created_at: now() };
      const chk = uniqueUserOk(db, u); if (!chk.ok) throw Object.assign(new Error('Duplicate ' + chk.field), { status: 400 });
      db.users.push(u);
      const conv_id = newId();
      db.conversations.push({ id: conv_id, title: `${body.unit_name} Official Space`, unit_id, created_by: user_id, created_at: now() });
      db.conversation_members.push({ conversation_id: conv_id, user_id });
      audit(db, 'USER', user_id, 'FIRST_ADMIN_CREATED', user_id, null, { organization: body.organization_name });
      return { ok: true, token: makeToken(user_id), user_id };
    });
    res.json(out);
  } catch (e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.post('/api/auth/login', rateLimitAuth, async (req, res) => {
  try {
    const { login, password } = req.body || {};
    const db = loadDb();
    const user = db.users.find(u => u.status === 'ACTIVE' && loginMatch(u, login));
    if (!user || !verifyPassword(password, user.password_salt, user.password_hash, user.password_iterations)) {
      mutate(db => audit(db, 'SECURITY', 'LOGIN', 'FAILED_LOGIN', user ? user.id : null, null, { login_hash: sha256Text(String(login || '').toLowerCase()) }));
      return res.status(401).json({ detail: 'Invalid login or password' });
    }
    if (process.env.NEXO_REQUIRE_OTP === 'true') {
      cleanupOtps(db);
      const code = otpCode();
      db.otps.push({ id: newId(), user_id: user.id, purpose: 'LOGIN', otp_hash: otpDigest(code), attempts: 0, created_at: now(), expires_at: new Date(Date.now()+OTP_TTL_MS).toISOString(), used_at: null });
      audit(db, 'OTP', user.id, 'OTP_REQUESTED_LOGIN_AFTER_PASSWORD', user.id, null, { login });
      saveDb(db);
      const sent = await sendOtpToUser(user, code, 'LOGIN');
      return res.json({ otp_required: true, login, sent, message: sent.sent ? 'OTP sent' : 'OTP provider not configured. Ask admin to configure OTP_PROVIDER_URL or temporarily disable NEXO_REQUIRE_OTP.' });
    }
    audit(db, 'USER', user.id, 'LOGIN', user.id, null, { login });
    saveDb(db);
    res.json({ token: makeToken(user.id), user: safePublicUser(user) });
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});

app.post('/api/auth/logout', authRequired, (req, res) => {
  const h = req.headers.authorization || '';
  const payload = readToken(h.toLowerCase().startsWith('bearer ') ? h.slice(7).trim() : '');
  mutate(db => {
    if (payload && payload.jti) {
      db.revoked_tokens = (db.revoked_tokens || []).filter(t => (t.exp || 0) > Math.floor(Date.now()/1000));
      db.revoked_tokens.push({ jti: payload.jti, user_id: req.user.id, exp: payload.exp || 0, revoked_at: now() });
    }
    audit(db, 'USER', req.user.id, 'LOGOUT', req.user.id, null, null); return true;
  });
  res.json({ ok: true });
});
app.post('/api/auth/request-otp', rateLimitAuth, async (req, res) => {
  try {
    const { login, purpose, password } = req.body || {};
    const p = String(purpose || 'LOGIN').toUpperCase() === 'RESET' ? 'RESET' : 'LOGIN';
    const db = loadDb();
    const user = db.users.find(u => u.status === 'ACTIVE' && loginMatch(u, login));
    if (!user) {
      audit(db, 'SECURITY', 'OTP', 'OTP_REQUEST_UNKNOWN_ACCOUNT', null, null, { login_hash: sha256Text(String(login || '').toLowerCase()), purpose: p });
      saveDb(db);
      return res.json({ ok: true, message: 'If the account exists and is eligible, OTP will be sent.' });
    }
    if (p === 'LOGIN' && !verifyPassword(password, user.password_salt, user.password_hash, user.password_iterations)) {
      audit(db, 'SECURITY', 'OTP', 'OTP_REQUEST_BAD_PASSWORD', user.id, null, { login_hash: sha256Text(String(login || '').toLowerCase()) });
      saveDb(db);
      return res.json({ ok: true, message: 'If the account exists and is eligible, OTP will be sent.' });
    }
    cleanupOtps(db);
    const code = otpCode();
    db.otps.push({ id: newId(), user_id: user.id, purpose: p, otp_hash: otpDigest(code), attempts: 0, created_at: now(), expires_at: new Date(Date.now()+OTP_TTL_MS).toISOString(), used_at: null });
    audit(db, 'OTP', user.id, 'OTP_REQUESTED_' + p, user.id, null, { login });
    saveDb(db);
    const sent = await sendOtpToUser(user, code, p);
    const resp = { ok: true, sent, message: sent.sent ? 'OTP sent' : 'OTP provider not configured. Contact admin.' };
    if (SHOW_DEV_OTP) resp.dev_otp = code;
    res.json(resp);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.post('/api/auth/login-otp', rateLimitAuth, (req, res) => {
  try {
    const { login, otp } = req.body || {};
    const out = mutate(db => {
      const user = db.users.find(u => u.status === 'ACTIVE' && loginMatch(u, login));
      if (!user) { audit(db, 'SECURITY', 'OTP', 'OTP_LOGIN_UNKNOWN_ACCOUNT', null, null, { login_hash: sha256Text(String(login || '').toLowerCase()) }); throw Object.assign(new Error('Invalid login or OTP'), { status: 401 }); }
      try { verifyOtp(db, user.id, 'LOGIN', otp); } catch(e) { audit(db, 'SECURITY', 'OTP', 'OTP_LOGIN_FAILED', user.id, null, { login_hash: sha256Text(String(login || '').toLowerCase()) }); throw Object.assign(new Error('Invalid login or OTP'), { status: e.status || 401 }); }
      audit(db, 'USER', user.id, 'OTP_LOGIN', user.id, null, { login });
      return { token: makeToken(user.id), user: safePublicUser(user) };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.post('/api/auth/reset-password', rateLimitAuth, (req, res) => {
  try {
    const { login, otp, new_password } = req.body || {};
    const pe = passwordPolicyError(new_password); if (pe) return res.status(400).json({ detail: pe });
    const out = mutate(db => {
      const user = db.users.find(u => u.status === 'ACTIVE' && loginMatch(u, login));
      if (!user) { audit(db, 'SECURITY', 'RESET', 'PASSWORD_RESET_UNKNOWN_ACCOUNT', null, null, { login_hash: sha256Text(String(login || '').toLowerCase()) }); throw Object.assign(new Error('Invalid reset request'), { status: 401 }); }
      try { verifyOtp(db, user.id, 'RESET', otp); } catch(e) { audit(db, 'SECURITY', 'RESET', 'PASSWORD_RESET_OTP_FAILED', user.id, null, { login_hash: sha256Text(String(login || '').toLowerCase()) }); throw Object.assign(new Error('Invalid reset request'), { status: e.status || 401 }); }
      const hp = hashPassword(new_password);
      user.password_salt = hp.salt; user.password_hash = hp.digest; user.password_iterations = hp.iterations; user.updated_at = now();
      audit(db, 'USER', user.id, 'PASSWORD_RESET_BY_OTP', user.id, null, { login });
      return { ok: true };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.get('/api/me', authRequired, (req, res) => res.json(safePublicUser(req.user)));
app.get('/api/units', authRequired, (req, res) => read(db => res.json(db.units.slice().sort((a,b) => (a.organization_name + a.name).localeCompare(b.organization_name + b.name)))));
app.post('/api/units', authRequired, requireAdmin, (req, res) => {
  const out = mutate(db => {
    const org = req.body.organization_name || (db.units.find(u => u.id === req.user.unit_id) || {}).organization_name || 'NEXO';
    const id = newId();
    db.units.push({ id, name: req.body.name, parent_unit_id: req.body.parent_unit_id || null, organization_name: org, created_at: now() });
    audit(db, 'UNIT', id, 'CREATED', req.user.id, null, req.body);
    return { id };
  });
  res.json(out);
});
app.get('/api/users', authRequired, (req, res) => read(db => {
  const visible = visibleUserIdsFor(db, req.user);
  const rows = db.users.filter(u => visible.has(u.id)).map(u => ({ ...safePublicUser(u), unit_name: (db.units.find(x => x.id === u.unit_id) || {}).name || null })).sort((a,b) => (a.role + a.name).localeCompare(b.role + b.name));
  res.json(rows);
}));
app.get('/api/users/all', authRequired, requireAdmin, (req, res) => read(db => {
  const rows = db.users.map(u => ({ ...safePublicUser(u), unit_name: (db.units.find(x => x.id === u.unit_id) || {}).name || null })).sort((a,b) => (a.role + a.name).localeCompare(b.role + b.name));
  res.json(rows);
}));
app.get('/api/subordinates', authRequired, (req, res) => read(db => {
  const rows = db.users.filter(u => isDirectOrIndirectReport(db, req.user.id, u.id)).map(safePublicUser);
  res.json(rows);
}));
app.post('/api/users', authRequired, requireAdmin, (req, res) => {
  try {
    const body = req.body || {};
    if (!body.name || !body.password || !body.designation) return res.status(400).json({ detail: 'Missing required fields' });
    const pe = passwordPolicyError(body.password); if (pe) return res.status(400).json({ detail: pe });
    const out = mutate(db => {
      const hp = hashPassword(body.password);
      const id = newId();
      const unit_id = body.unit_id || req.user.unit_id || null;
      const u = { id, name: body.name, mobile: body.mobile || null, email: body.email || null, employee_id: body.employee_id || null, password_salt: hp.salt, password_hash: hp.digest, password_iterations: hp.iterations, designation: body.designation, rank: body.rank || null, role: body.role || 'STAFF', unit_id, reports_to_user_id: body.reports_to_user_id || null, status: 'ACTIVE', created_at: now() };
      const chk = uniqueUserOk(db, u); if (!chk.ok) throw Object.assign(new Error('Duplicate mobile/email/employee ID: ' + chk.field), { status: 400 });
      db.users.push(u);
      db.conversations.filter(c => c.unit_id === unit_id).forEach(c => { if (!db.conversation_members.some(m => m.conversation_id === c.id && m.user_id === id)) db.conversation_members.push({ conversation_id: c.id, user_id: id }); });
      audit(db, 'USER', id, 'CREATED', req.user.id, null, body);
      return { id };
    });
    res.json(out);
  } catch (e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.get('/api/hierarchy', authRequired, (req, res) => read(db => res.json({ units: db.units, users: db.users.map(u => ({ id: u.id, name: u.name, designation: u.designation, rank: u.rank, role: u.role, unit_id: u.unit_id, reports_to_user_id: u.reports_to_user_id, status: u.status })) })));
app.get('/api/conversations', authRequired, (req, res) => read(db => {
  const ids = db.conversation_members.filter(m => m.user_id === req.user.id).map(m => m.conversation_id);
  res.json(db.conversations.filter(c => ids.includes(c.id)).sort((a,b) => b.created_at.localeCompare(a.created_at)));
}));
app.post('/api/conversations', authRequired, (req, res) => {
  const out = mutate(db => {
    const id = newId();
    const unit_id = req.body.unit_id || req.user.unit_id || null;
    db.conversations.push({ id, title: req.body.title, unit_id, created_by: req.user.id, created_at: now() });
    const members = new Set([req.user.id, ...(req.body.member_ids || [])]);
    if (unit_id) db.users.filter(u => u.unit_id === unit_id && u.status === 'ACTIVE').forEach(u => members.add(u.id));
    members.forEach(user_id => db.conversation_members.push({ conversation_id: id, user_id }));
    audit(db, 'CONVERSATION', id, 'CREATED', req.user.id, null, req.body);
    return { id };
  });
  res.json(out);
});
app.get('/api/messages', authRequired, (req, res) => read(db => {
  const conversation_id = req.query.conversation_id;
  if (!db.conversation_members.some(m => m.conversation_id === conversation_id && m.user_id === req.user.id)) return res.status(403).json({ detail: 'Not a member of this conversation' });
  const rows = db.messages.filter(m => m.conversation_id === conversation_id).map(m => { const u = db.users.find(x => x.id === m.sender_id) || {}; return { ...m, sender_name: u.name, sender_designation: u.designation }; }).sort((a,b) => a.created_at.localeCompare(b.created_at));
  res.json(rows);
}));
app.post('/api/messages', authRequired, (req, res) => {
  try {
    const out = mutate(db => {
      const body = req.body;
      if (!db.conversation_members.some(m => m.conversation_id === body.conversation_id && m.user_id === req.user.id)) throw Object.assign(new Error('Not a member of this conversation'), { status: 403 });
      const id = newId();
      const m = { id, conversation_id: body.conversation_id, sender_id: req.user.id, message_text: body.message_text, message_type: (body.message_type || 'GENERAL').toUpperCase(), priority: (body.priority || 'NORMAL').toUpperCase(), attachment_id: body.attachment_id || null, created_at: now() };
      db.messages.push(m);
      audit(db, 'MESSAGE', id, 'SENT', req.user.id, null, body);
      return { id };
    });
    res.json(out);
  } catch (e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.post('/api/commands', authRequired, (req, res) => {
  try {
    if (!canIssue(req.user)) return res.status(403).json({ detail: 'You cannot issue official instructions' });
    const out = mutate(db => {
      const body = req.body || {};
      let recipients = resolveRecipients(db, body, req.user);
      if (!recipients.length) throw Object.assign(new Error('No recipients selected'), { status: 400 });
      let message_id = null;
      if (body.conversation_id) {
        message_id = newId();
        db.messages.push({ id: message_id, conversation_id: body.conversation_id, sender_id: req.user.id, message_text: body.description, message_type: (body.command_type || 'INSTRUCTION').toUpperCase(), priority: (body.priority || 'NORMAL').toUpperCase(), attachment_id: (body.attachment_ids || [])[0] || null, created_at: now() });
      }
      const hierarchy = reportingChain(db, req.user.id);
      const hierarchy_hash = sha256Text(stableStringify(hierarchy));
      const recipient_hash = sha256Text(stableStringify(recipients));
      const created_at = now();
      const command_hash = sha256Text(stableStringify({ title: body.title, description: body.description, type: body.command_type, issuer: req.user.id, recipients, deadline: body.deadline, created_at }) + hierarchy_hash + recipient_hash);
      const id = newId();
      db.commands.push({ id, message_id, title: body.title, description: body.description, command_type: (body.command_type || 'INSTRUCTION').toUpperCase(), issuer_user_id: req.user.id, priority: (body.priority || 'NORMAL').toUpperCase(), deadline: body.deadline || null, proof_required: !!body.proof_required, compliance_required: body.compliance_required !== false, attachment_ids: body.attachment_ids || [], command_hash, hierarchy_hash, recipient_hash, version: 1, status: 'ISSUED', created_at });
      recipients.forEach(user_id => db.command_recipients.push({ id: newId(), command_id: id, user_id, status: 'DELIVERED', delivered_at: now(), seen_at: null, acknowledged_at: null, in_progress_at: null, completed_at: null, proof_submitted_at: null, verified_at: null, closed_at: null, proof_text: null, proof_file_id: null, verified_by: null, remarks: null, last_updated: now() }));
      audit(db, 'COMMAND', id, 'ISSUED', req.user.id, null, { command_hash, recipients: recipients.length });
      return { id, recipients: recipients.length, command_hash };
    });
    res.json(out);
  } catch (e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.get('/api/commands', authRequired, (req, res) => read(db => {
  const scope = req.query.scope || 'all';
  let rows = [];
  if (scope === 'issued') rows = db.commands.filter(c => c.issuer_user_id === req.user.id);
  else if (scope === 'mine') rows = db.command_recipients.filter(cr => cr.user_id === req.user.id).map(cr => ({ ...db.commands.find(c => c.id === cr.command_id), my_status: cr.status, my_last_updated: cr.last_updated }));
  else {
    const ids = new Set(db.command_recipients.filter(cr => cr.user_id === req.user.id).map(cr => cr.command_id));
    rows = db.commands.filter(c => c.issuer_user_id === req.user.id || ids.has(c.id)).map(c => {
      const cr = db.command_recipients.find(x => x.command_id === c.id && x.user_id === req.user.id);
      return { ...c, my_status: cr ? cr.status : undefined, my_last_updated: cr ? cr.last_updated : undefined };
    });
  }
  rows = rows.filter(Boolean).map(c => ({ ...c, issuer_name: (db.users.find(u => u.id === c.issuer_user_id) || {}).name || '' })).sort((a,b) => b.created_at.localeCompare(a.created_at));
  res.json(rows);
}));
app.get('/api/commands/:id', authRequired, (req, res) => read(db => {
  const c = db.commands.find(x => x.id === req.params.id); if (!c) return res.status(404).json({ detail: 'Command not found' });
  const allowed = c.issuer_user_id === req.user.id || db.command_recipients.some(cr => cr.command_id === c.id && cr.user_id === req.user.id) || ['SUPER_ADMIN','ORG_ADMIN'].includes(req.user.role);
  if (!allowed) return res.status(403).json({ detail: 'Not allowed' });
  const u = db.users.find(x => x.id === c.issuer_user_id) || {};
  res.json({ ...c, issuer_name: u.name, issuer_designation: u.designation });
}));
app.get('/api/commands/:id/compliance', authRequired, (req, res) => read(db => {
  const c = db.commands.find(x => x.id === req.params.id); if (!c) return res.status(404).json({ detail: 'Command not found' });
  const allowed = c.issuer_user_id === req.user.id || ['SUPER_ADMIN','ORG_ADMIN'].includes(req.user.role) || db.command_recipients.some(cr => cr.command_id === c.id && cr.user_id === req.user.id);
  if (!allowed) return res.status(403).json({ detail: 'Not allowed' });
  const recipients = db.command_recipients.filter(cr => cr.command_id === c.id).map(cr => { const u = db.users.find(x => x.id === cr.user_id) || {}; return { ...cr, name: u.name, designation: u.designation, role: u.role, unit_id: u.unit_id }; }).sort((a,b) => String(a.name).localeCompare(String(b.name)));
  const counts = { TOTAL: recipients.length, DELIVERED:0, SEEN:0, ACKNOWLEDGED:0, IN_PROGRESS:0, COMPLETED:0, PROOF_SUBMITTED:0, VERIFIED:0, CLOSED:0, CLARIFICATION:0 };
  const order = ['DELIVERED','SEEN','ACKNOWLEDGED','IN_PROGRESS','COMPLETED','PROOF_SUBMITTED','VERIFIED','CLOSED']; const idx = Object.fromEntries(order.map((s,i)=>[s,i]));
  recipients.forEach(r => { if (counts[r.status] !== undefined) counts[r.status]++; if (idx[r.status] !== undefined) for (const s of order.slice(0, idx[r.status]+1)) counts[s + '_OR_MORE'] = (counts[s + '_OR_MORE'] || 0) + 1; });
  res.json({ command: c, summary: counts, recipients });
}));
app.post('/api/commands/:id/my-status', authRequired, (req, res) => {
  try {
    const allowedStatus = new Set(['SEEN','ACKNOWLEDGED','IN_PROGRESS','COMPLETED','PROOF_SUBMITTED','CLARIFICATION']);
    const st = String(req.body.status || '').toUpperCase();
    if (!allowedStatus.has(st)) return res.status(400).json({ detail: 'Invalid status' });
    const out = mutate(db => {
      const cr = db.command_recipients.find(x => x.command_id === req.params.id && x.user_id === req.user.id); if (!cr) throw Object.assign(new Error('This command is not assigned to you'), { status: 403 });
      const old = cr.status || 'DELIVERED';
      if (!allowedTransition(old, st)) throw Object.assign(new Error(`Invalid compliance sequence: ${old} → ${st}`), { status: 400 });
      if (req.body.proof_file_id && !canAccessFile(db, req.user, req.body.proof_file_id)) throw Object.assign(new Error('Proof file access denied'), { status: 403 });
      cr.status = st; cr.last_updated = now(); cr.remarks = req.body.remarks || cr.remarks; cr.proof_text = req.body.proof_text || cr.proof_text; if (req.body.proof_file_id) cr.proof_file_id = req.body.proof_file_id;
      const fieldMap = { SEEN:'seen_at', ACKNOWLEDGED:'acknowledged_at', IN_PROGRESS:'in_progress_at', COMPLETED:'completed_at', PROOF_SUBMITTED:'proof_submitted_at', CLARIFICATION:'clarification_at' };
      cr[fieldMap[st]] = now();
      audit(db, 'COMMAND_RECIPIENT', cr.id, 'STATUS_' + st, req.user.id, old, st);
      return { ok: true, status: st };
    });
    res.json(out);
  } catch (e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.post('/api/commands/:id/verify', authRequired, (req, res) => {
  try {
    const out = mutate(db => {
      const c = db.commands.find(x => x.id === req.params.id); if (!c) throw Object.assign(new Error('Command not found'), { status: 404 });
      if (c.issuer_user_id !== req.user.id && !['SUPER_ADMIN','ORG_ADMIN'].includes(req.user.role)) throw Object.assign(new Error('Only issuer/admin can verify'), { status: 403 });
      const cr = db.command_recipients.find(x => x.command_id === c.id && x.user_id === req.body.user_id); if (!cr) throw Object.assign(new Error('Recipient not found'), { status: 404 });
      const old = cr.status; cr.status = 'VERIFIED'; cr.verified_at = now(); cr.verified_by = req.user.id; cr.remarks = req.body.remarks || cr.remarks; cr.last_updated = now();
      audit(db, 'COMMAND_RECIPIENT', cr.id, 'VERIFIED', req.user.id, old, 'VERIFIED');
      return { ok: true };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.post('/api/commands/:id/clarifications', authRequired, (req, res) => {
  try {
    const out = mutate(db => {
      if (!db.command_recipients.some(cr => cr.command_id === req.params.id && cr.user_id === req.user.id)) throw Object.assign(new Error('Only assigned recipient can ask clarification'), { status: 403 });
      const id = newId();
      db.clarifications.push({ id, command_id: req.params.id, asked_by: req.user.id, question_text: req.body.question_text, answered_by: null, answer_text: null, status: 'OPEN', asked_at: now(), answered_at: null });
      audit(db, 'CLARIFICATION', id, 'ASKED', req.user.id, null, req.body.question_text);
      return { id };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.get('/api/commands/:id/clarifications', authRequired, (req, res) => read(db => {
  if (!canReadCommand(db, req.user, req.params.id)) return res.status(403).json({ detail: 'Not allowed' });
  const rows = db.clarifications.filter(cl => cl.command_id === req.params.id).map(cl => ({ ...cl, asked_by_name: (db.users.find(u=>u.id===cl.asked_by)||{}).name, answered_by_name: (db.users.find(u=>u.id===cl.answered_by)||{}).name })).sort((a,b) => a.asked_at.localeCompare(b.asked_at));
  res.json(rows);
}));
app.post('/api/clarifications/:id/answer', authRequired, (req, res) => {
  try {
    const out = mutate(db => {
      const cl = db.clarifications.find(x => x.id === req.params.id); if (!cl) throw Object.assign(new Error('Clarification not found'), { status: 404 });
      const c = db.commands.find(x => x.id === cl.command_id);
      if (!c || (c.issuer_user_id !== req.user.id && !['SUPER_ADMIN','ORG_ADMIN'].includes(req.user.role))) throw Object.assign(new Error('Only issuer/admin can answer'), { status: 403 });
      cl.answered_by = req.user.id; cl.answer_text = req.body.answer_text; cl.status = 'ANSWERED'; cl.answered_at = now();
      audit(db, 'CLARIFICATION', cl.id, 'ANSWERED', req.user.id, null, req.body.answer_text);
      return { ok: true };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });
app.post('/api/files', authRequired, upload.single('file'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ detail: 'File missing' });
    const ext = validateUploadFile(req.file);
    const out = mutate(db => {
      const id = newId();
      const safe = (req.file.originalname || 'file.bin').replace(/[^a-zA-Z0-9._\- ]/g, '').slice(0,150) || 'file.bin';
      const stored = path.join(UPLOAD_DIR, `${id}_${safe}`);
      fs.writeFileSync(stored, req.file.buffer);
      const digest = sha256Bytes(req.file.buffer);
      const mime_type = safeMimeFor(safe);
      db.attachments.push({ id, filename: safe, stored_path: stored, sha256: digest, mime_type, uploaded_by: req.user.id, created_at: now() });
      audit(db, 'FILE', id, 'UPLOADED', req.user.id, null, { filename: safe, sha256: digest, ext });
      return { id, filename: safe, sha256: digest, mime_type };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});

function safeMimeFor(filename) {
  const ext = extOf(filename);
  return ({ '.pdf':'application/pdf', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.gif':'image/gif', '.webp':'image/webp', '.txt':'text/plain; charset=utf-8', '.csv':'text/csv; charset=utf-8', '.json':'application/json; charset=utf-8' })[ext] || 'application/octet-stream';
}
function isPreviewable(filename){ return PREVIEW_EXTS.has(extOf(filename)); }
function sendFileRecord(req, res, disposition) {
  const user = req.user;
  if (!user) return res.status(401).send('Authentication required');
  return read(db => {
    const f = db.attachments.find(x => x.id === req.params.id);
    if (!f) return res.status(404).send('File not found');
    if (!canAccessFile(db, user, f.id)) return res.status(403).send('File access denied');
    if (!fs.existsSync(f.stored_path)) return res.status(404).send('Stored file missing');
    const preview = disposition === 'inline';
    if (preview && !isPreviewable(f.filename)) return res.status(415).send('Preview not allowed for this file type');
    res.setHeader('Content-Type', f.mime_type || safeMimeFor(f.filename));
    res.setHeader('Content-Disposition', `${disposition}; filename*=UTF-8''${encodeURIComponent(f.filename)}`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store');
    fs.createReadStream(f.stored_path).pipe(res);
  });
}
app.get('/api/files/:id/meta', authRequired, (req, res) => read(db => {
  const f = db.attachments.find(x => x.id === req.params.id);
  if (!f) return res.status(404).json({ detail: 'File not found' });
  if (!canAccessFile(db, req.user, f.id)) return res.status(403).json({ detail: 'File access denied' });
  res.json({ id: f.id, filename: f.filename, sha256: f.sha256, mime_type: f.mime_type || safeMimeFor(f.filename), uploaded_by: f.uploaded_by, created_at: f.created_at, view_url: `/api/files/${f.id}/view`, download_url: `/api/files/${f.id}/download` });
}));
app.get('/api/files/:id/view', authRequired, (req, res) => sendFileRecord(req, res, 'inline'));
app.get('/api/files/:id/download', authRequired, (req, res) => sendFileRecord(req, res, 'attachment'));
app.get('/api/files/:id', authRequired, (req, res) => sendFileRecord(req, res, 'inline'));
app.post('/api/users/:id/reset-password', authRequired, requireAdmin, (req, res) => {
  try {
    const out = mutate(db => {
      const u = db.users.find(x => x.id === req.params.id);
      if (!u) throw Object.assign(new Error('User not found'), { status: 404 });
      const pe = passwordPolicyError(req.body.password); if (pe) throw Object.assign(new Error(pe), { status: 400 });
      const hp = hashPassword(req.body.password);
      u.password_salt = hp.salt; u.password_hash = hp.digest; u.password_iterations = hp.iterations; u.updated_at = now();
      audit(db, 'USER', u.id, 'PASSWORD_RESET_BY_ADMIN', req.user.id, null, { user: u.name });
      return { ok: true };
    });
    res.json(out);
  } catch(e) { res.status(e.status || 500).json({ detail: e.message || 'Server error' }); }
});
app.get('/api/audit', authRequired, requireAdmin, (req, res) => read(db => {
  const limit = Math.min(parseInt(req.query.limit || '100', 10), 500);
  res.json(db.audit_logs.slice().sort((a,b) => b.audit_id - a.audit_id).slice(0, limit));
}));
app.post('/api/audit/checkpoint', authRequired, requireAdmin, (req, res) => {
  const out = mutate(db => createAuditAnchor(db, req.body && req.body.reason || 'MANUAL'));
  res.json(out || { ok: false, detail: 'No audit logs' });
});
app.get('/api/audit/anchors', authRequired, requireAdmin, (req, res) => read(db => res.json((db.audit_anchors || []).slice().reverse().slice(0,100))));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ detail: 'Server error' }); });

const PORT = process.env.PORT || process.env.HTTP_PLATFORM_PORT || 8000;
app.listen(PORT, () => console.log(`${APP_NAME} v${VERSION} running on port ${PORT}`));
